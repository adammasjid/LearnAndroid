// main function
fun main() {
    val ranges = 1.rangeTo(5)

    for (i in ranges){
        println("value is $i!")
    }
}